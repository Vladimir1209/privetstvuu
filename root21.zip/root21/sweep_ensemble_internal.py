import os
import argparse
import numpy as np
import pandas as pd

# IMPORTANT: file must be рядом с walk_forward_ensemble_onefile.py
import walk_forward_ensemble_onefile as wf


def run_single(params: dict):
    import sys
    sys.argv = ["walk_forward_ensemble_onefile.py"]
    for k, v in params.items():
        sys.argv += [f"--{k}", str(v)]
    wf.main()


def read_results(out_dir: str):
    p = os.path.join(out_dir, "walk_forward_results.csv")
    df = pd.read_csv(p)
    return {
        "mean_pf": float(df["profit_factor"].mean()),
        "mean_ret": float(df["return_pct"].mean()),
        "worst_ret": float(df["return_pct"].min()),
        "best_ret": float(df["return_pct"].max()),
        "mean_trades": float(df["trades"].mean()),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--labels", required=True)
    ap.add_argument("--csv", required=True)
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", default="sweep_internal")

    ap.add_argument("--train_months", type=int, default=6)
    ap.add_argument("--test_months", type=int, default=2)

    ap.add_argument("--ensemble", type=int, default=5)
    ap.add_argument("--votes", default="3,4,5")

    ap.add_argument("--conf_from", type=float, default=0.50)
    ap.add_argument("--conf_to", type=float, default=0.70)
    ap.add_argument("--conf_step", type=float, default=0.02)

    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--torch_threads", type=int, default=1)

    ap.add_argument("--risk_pct", type=float, default=0.01)
    ap.add_argument("--fee", type=float, default=0.0004)
    ap.add_argument("--horizon", type=int, default=200)
    ap.add_argument("--no_overlap", type=int, default=1)

    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    votes_list = [int(x.strip()) for x in args.votes.split(",") if x.strip()]
    confs = np.arange(args.conf_from, args.conf_to + 1e-12, args.conf_step)

    rows = []
    for mv in votes_list:
        for conf in confs:
            run_dir = os.path.join(args.out, f"mv{mv}_c{conf:.2f}".replace(".", "_"))
            params = {
                "labels": args.labels,
                "csv": args.csv,
                "dataset": args.dataset,
                "out": run_dir,
                "train_months": args.train_months,
                "test_months": args.test_months,
                "conf": float(conf),
                "risk_pct": args.risk_pct,
                "fee": args.fee,
                "horizon": args.horizon,
                "no_overlap": args.no_overlap,
                "epochs": args.epochs,
                "bs": args.bs,
                "torch_threads": args.torch_threads,
                "ensemble": args.ensemble,
                "min_votes": mv,
            }

            print(f"RUN mv={mv} conf={conf:.2f}")
            run_single(params)

            m = read_results(run_dir)
            m.update({"min_votes": mv, "conf": float(conf)})
            rows.append(m)
            print(f"  -> mean_pf={m['mean_pf']:.3f} mean_ret={m['mean_ret']:.3f} mean_trades={m['mean_trades']:.1f}")

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(args.out, "sweep_results.csv"), index=False)

    top = df.sort_values(["mean_ret", "mean_pf"], ascending=False).head(10)
    top.to_csv(os.path.join(args.out, "top10.csv"), index=False)

    print("DONE SWEEP")
    print(top)


if __name__ == "__main__":
    main()
