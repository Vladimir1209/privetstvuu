import os, json, argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn


# ---------- helpers (same as your risk script) ----------
def safe_time_parse(series: pd.Series) -> pd.Series:
    s = series.copy()
    s_num = pd.to_numeric(s, errors="coerce")
    vals = s_num.to_numpy(dtype=np.float64)
    vals = vals[np.isfinite(vals)]
    if vals.size == 0:
        return pd.to_datetime(s, utc=True, errors="coerce")
    med = float(np.nanmedian(vals))
    if med > 1e17:
        return pd.to_datetime(s_num.astype("Int64"), unit="ns", utc=True, errors="coerce")
    if med > 1e12:
        return pd.to_datetime(s_num.astype("Int64"), unit="ms", utc=True, errors="coerce")
    if med > 1e9:
        return pd.to_datetime(s_num.astype("Int64"), unit="s", utc=True, errors="coerce")
    return pd.to_datetime(s_num, utc=True, errors="coerce")


def load_ohlcv(csv_path: str) -> pd.DataFrame:
    df0 = pd.read_csv(csv_path)
    if df0.shape[1] < 5:
        df0 = pd.read_csv(csv_path, header=None)
    cols = list(df0.columns)
    lower = [str(c).strip().lower() for c in cols]

    def find_any(names):
        for n in names:
            for i, c in enumerate(lower):
                if c == n:
                    return cols[i]
        return None

    time_col = find_any(["open_time","opentime","timestamp","time","date","datetime"])
    o_col = find_any(["open","o"])
    h_col = find_any(["high","h"])
    l_col = find_any(["low","l"])
    c_col = find_any(["close","c"])
    if any(x is None for x in [time_col,o_col,h_col,l_col,c_col]):
        time_col,o_col,h_col,l_col,c_col = cols[0],cols[1],cols[2],cols[3],cols[4]

    d = pd.DataFrame({
        "time_raw": df0[time_col],
        "open": pd.to_numeric(df0[o_col], errors="coerce"),
        "high": pd.to_numeric(df0[h_col], errors="coerce"),
        "low":  pd.to_numeric(df0[l_col], errors="coerce"),
        "close":pd.to_numeric(df0[c_col], errors="coerce"),
    }).dropna().reset_index(drop=True)

    d["time"] = safe_time_parse(d["time_raw"])
    if d["time"].notna().mean() >= 0.5:
        d = d.dropna(subset=["time"]).sort_values("time").reset_index(drop=True)
    else:
        d["time"] = pd.NaT
    return d


class TradeNet(nn.Module):
    def __init__(self, n_features: int, hidden=128, cnn_channels=128, dropout=0.1, use_outcome=True):
        super().__init__()
        self.use_outcome = use_outcome
        self.cnn = nn.Sequential(
            nn.Conv1d(n_features, cnn_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.gru = nn.GRU(input_size=cnn_channels, hidden_size=hidden, num_layers=1,
                          batch_first=True, bidirectional=True)
        feat_dim = hidden * 2
        self.head_side = nn.Sequential(
            nn.Linear(feat_dim, feat_dim//2), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(feat_dim//2, 2)
        )
        self.head_reg = nn.Sequential(
            nn.Linear(feat_dim, feat_dim//2), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(feat_dim//2, 3)
        )
        if self.use_outcome:
            self.head_out = nn.Sequential(
                nn.Linear(feat_dim, feat_dim//2), nn.ReLU(), nn.Dropout(dropout),
                nn.Linear(feat_dim//2, 3)
            )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.cnn(x)
        x = x.transpose(1, 2)
        out, _ = self.gru(x)
        feat = out[:, -1, :]
        side_logits = self.head_side(feat)
        reg = self.head_reg(feat)
        out_logits = self.head_out(feat) if self.use_outcome else None
        return side_logits, reg, out_logits


def time_split_indices(n: int, val_frac=0.15, test_frac=0.15):
    n_test = int(n * test_frac)
    n_val = int(n * val_frac)
    train_end = n - (n_val + n_test)
    val_end = n - n_test
    return np.arange(0, train_end), np.arange(train_end, val_end), np.arange(val_end, n)


def evaluate_trade_ohlc(df: pd.DataFrame, side: str, entry_i: int, sl: float, tp: float, horizon: int):
    h = df["high"].to_numpy(np.float64)
    l = df["low"].to_numpy(np.float64)
    end = min(len(df), entry_i + 1 + horizon)

    for i in range(entry_i + 1, end):
        if side == "LONG":
            hit_sl = l[i] <= sl
            hit_tp = h[i] >= tp
            if hit_sl and hit_tp:
                return "SL", i
            if hit_sl:
                return "SL", i
            if hit_tp:
                return "TP", i
        else:
            hit_sl = h[i] >= sl
            hit_tp = l[i] <= tp
            if hit_sl and hit_tp:
                return "SL", i
            if hit_sl:
                return "SL", i
            if hit_tp:
                return "TP", i
    return "TIMEOUT", end - 1


def max_drawdown_money(equity: np.ndarray) -> float:
    if len(equity) == 0:
        return 0.0
    peak = -1e30
    mdd = 0.0
    for x in equity:
        if x > peak:
            peak = x
        dd = peak - x
        if dd > mdd:
            mdd = dd
    return float(mdd)


# ---------- sweep core ----------
@torch.no_grad()
def backtest_risk_one_conf(conf: float, args, labels, df, test_idx, model, mean, std, device, use_cuda):
    samples_dir = os.path.join(args.data, "samples")

    cap = float(args.start_capital)
    busy_until = -1
    equity = []
    n_tr = 0
    wins = 0
    losses = 0
    gp = 0.0
    gl = 0.0

    for idx in test_idx.astype(int):
        row = labels.loc[idx]
        entry_i = int(row["entry_i"])

        if args.no_overlap and entry_i <= busy_until:
            continue

        sid = str(row["sample_id"]).zfill(7)
        X = np.load(os.path.join(samples_dir, f"{sid}.npz"))["X"].astype(np.float32)
        Xn = (X - mean[None, :]) / (std[None, :] + 1e-8)
        Xt = torch.from_numpy(Xn).unsqueeze(0).to(device)

        with torch.amp.autocast("cuda", enabled=use_cuda):
            side_logits, _, _ = model(Xt)

        p = torch.softmax(side_logits, dim=1)[0].detach().cpu().numpy()
        pred_side = "LONG" if int(np.argmax(p)) == 1 else "SHORT"
        c = float(max(p[0], p[1]))
        if c < conf:
            continue

        entry = float(row["entry"])
        sl = float(row["sl"])
        tp = float(row["tp"])

        risk_dist = abs(entry - sl)
        if risk_dist <= 0 or entry <= 0 or cap <= 0:
            continue

        risk_money = cap * float(args.risk_pct)
        qty = risk_money / risk_dist  # units

        outcome, exit_i = evaluate_trade_ohlc(df, pred_side, entry_i, sl, tp, args.horizon)
        exit_price = {"TP": tp, "SL": sl, "TIMEOUT": float(df.loc[exit_i, "close"])}[outcome]

        if pred_side == "LONG":
            pnl_money = (exit_price - entry) * qty
        else:
            pnl_money = (entry - exit_price) * qty

        fee = float(args.fee)
        fees_money = fee * (abs(entry * qty) + abs(exit_price * qty))
        pnl_net = pnl_money - fees_money

        cap_new = cap + pnl_net

        n_tr += 1
        if pnl_net > 0:
            wins += 1
            gp += pnl_net
        else:
            losses += 1
            gl += -pnl_net

        cap = cap_new
        equity.append(cap)

        if args.no_overlap:
            busy_until = int(exit_i)

        if cap <= 0:
            break

    if n_tr == 0:
        return {
            "conf": conf, "trades": 0, "winrate": None, "profit_factor": None,
            "start_capital": float(args.start_capital), "end_capital": float(args.start_capital),
            "return_pct": 0.0, "max_drawdown_money": None
        }

    pf = (gp / gl) if gl > 1e-12 else float("inf")
    winrate = wins / n_tr
    end_cap = float(cap)
    ret = end_cap / float(args.start_capital) - 1.0
    mdd = max_drawdown_money(np.array(equity, dtype=np.float64))

    return {
        "conf": conf,
        "trades": n_tr,
        "winrate": winrate,
        "wins": wins,
        "losses": losses,
        "profit_factor": pf,
        "start_capital": float(args.start_capital),
        "end_capital": end_cap,
        "return_pct": ret,
        "max_drawdown_money": mdd,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--model_dir", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--out", default="sweep_conf_risk")

    ap.add_argument("--horizon", type=int, default=200)
    ap.add_argument("--fee", type=float, default=0.0004)

    ap.add_argument("--start_capital", type=float, default=1000.0)
    ap.add_argument("--risk_pct", type=float, default=0.01)
    ap.add_argument("--no_overlap", type=int, default=1)

    ap.add_argument("--conf_from", type=float, default=0.55)
    ap.add_argument("--conf_to", type=float, default=0.85)
    ap.add_argument("--conf_step", type=float, default=0.02)

    ap.add_argument("--val_frac", type=float, default=0.15)
    ap.add_argument("--test_frac", type=float, default=0.15)

    ap.add_argument("--hidden", type=int, default=128)
    ap.add_argument("--cnn_channels", type=int, default=128)
    ap.add_argument("--dropout", type=float, default=0.1)

    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    labels = pd.read_csv(args.labels)
    if "entry_i" in labels.columns:
        labels = labels.sort_values("entry_i").reset_index(drop=True)

    split_path = os.path.join(args.model_dir, "split.json")
    if os.path.exists(split_path):
        split = json.load(open(split_path, "r", encoding="utf-8"))
        te0, te1 = split["test"]
        test_idx = np.arange(int(te0), int(te1) + 1)
    else:
        _, _, test_idx = time_split_indices(len(labels), val_frac=args.val_frac, test_frac=args.test_frac)

    df = load_ohlcv(args.csv)

    ckpt = torch.load(args.model, map_location="cpu")
    st = np.load(args.stats)
    mean = st["mean"].astype(np.float32)
    std = st["std"].astype(np.float32)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_cuda = torch.cuda.is_available()

    model = TradeNet(
        n_features=int(ckpt["n_features"]),
        hidden=int(ckpt.get("hidden", args.hidden)),
        cnn_channels=int(ckpt.get("cnn_channels", args.cnn_channels)),
        dropout=float(ckpt.get("dropout", args.dropout)),
        use_outcome=bool(ckpt.get("use_outcome", False)),
    ).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    confs = np.arange(args.conf_from, args.conf_to + 1e-12, args.conf_step)

    rows = []
    for conf in confs:
        res = backtest_risk_one_conf(float(conf), args, labels, df, test_idx, model, mean, std, device, use_cuda)
        rows.append(res)
        print(f"conf={conf:.2f} trades={res['trades']} pf={res['profit_factor']} ret={res['return_pct']:.4f} mdd={res['max_drawdown_money']}")

    out_csv = os.path.join(args.out, "sweep_conf_risk_results.csv")
    dfres = pd.DataFrame(rows)
    dfres.to_csv(out_csv, index=False)

    # pick best: maximize return_pct with constraint trades>=30 and pf>=1.0
    df_ok = dfres[(dfres["trades"] >= 30) & (dfres["profit_factor"].fillna(0) >= 1.0)].copy()
    best = None
    if len(df_ok) > 0:
        best = df_ok.sort_values(["return_pct", "profit_factor"], ascending=False).head(1).to_dict("records")[0]

    out_json = os.path.join(args.out, "best.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump({"best": best}, f, ensure_ascii=False, indent=2)

    print("DONE SWEEP RISK")
    print("Saved:", out_csv)
    print("Saved:", out_json)
    if best:
        print("BEST:", json.dumps(best, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
