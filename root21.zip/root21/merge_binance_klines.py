import os
import glob
import argparse
import numpy as np
import pandas as pd

BINANCE_COLS = [
    "open_time", "open", "high", "low", "close", "volume",
    "close_time", "quote_volume", "trades",
    "taker_buy_base_volume", "taker_buy_quote_volume", "ignore"
]

NEEDED = ["open_time", "open", "high", "low", "close", "volume"]

def _is_number_like(x: str) -> bool:
    try:
        float(str(x).strip().replace(",", "."))
        return True
    except Exception:
        return False

def sniff_sep(path: str) -> str:
    # простая эвристика: что чаще в первой строке
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        line = f.readline()
    return ";" if line.count(";") > line.count(",") else ","

def read_binance_csv_robust(path: str) -> pd.DataFrame:
    sep = sniff_sep(path)

    # 1) читаем первые 2 строки без заголовка, чтобы понять структуру
    preview = pd.read_csv(path, sep=sep, header=None, nrows=2, engine="python")
    if preview.shape[1] < 6:
        raise ValueError(f"Too few columns ({preview.shape[1]}). Wrong separator? sep='{sep}'")

    row0 = preview.iloc[0].tolist()
    # Binance без заголовка: первая строка должна быть числами (timestamp, цены, объём)
    looks_no_header = all(_is_number_like(row0[i]) for i in range(6))

    if looks_no_header:
        # 2a) читаем полностью как без заголовка
        df = pd.read_csv(path, sep=sep, header=None, engine="python")
        n = df.shape[1]
        if n < 6:
            raise ValueError(f"Parsed <6 columns ({n}) even as header=None. sep='{sep}'")
        df.columns = BINANCE_COLS[:n] + [f"extra_{i}" for i in range(max(0, n - len(BINANCE_COLS)))]
        df.columns = df.columns[:n]
    else:
        # 2b) читаем как с заголовком
        df = pd.read_csv(path, sep=sep, engine="python")
        df.columns = [str(c).strip().lower() for c in df.columns]
        rename_map = {
            "timestamp": "open_time",
            "open time": "open_time",
            "time": "open_time",
            "date": "open_time",
        }
        df = df.rename(columns=rename_map)

    # 3) проверка нужных колонок
    miss = [c for c in NEEDED if c not in df.columns]
    if miss:
        raise ValueError(f"missing columns {miss}. Columns={list(df.columns)[:20]}")

    # 4) типы + чистка
    df["open_time"] = pd.to_numeric(df["open_time"], errors="coerce")
    for c in ["open", "high", "low", "close", "volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["open_time", "open", "high", "low", "close"])
    df["open_time"] = df["open_time"].astype(np.int64)

    # 5) оставим нужное (и close_time, если есть)
    keep = ["open_time", "open", "high", "low", "close", "volume"]
    if "close_time" in df.columns:
        df["close_time"] = pd.to_numeric(df["close_time"], errors="coerce")
        keep.append("close_time")
    df = df[keep]

    return df


def merge_folder(inp: str, out_csv: str):
    files = sorted(glob.glob(os.path.join(inp, "*.csv")))
    if not files:
        raise FileNotFoundError(f"No .csv found in {inp}")

    parts = []
    ok = 0
    for f in files:
        try:
            d = read_binance_csv_robust(f)
            parts.append(d)
            ok += 1
            print(f"[OK] {os.path.basename(f)} rows={len(d)}")
        except Exception as e:
            print(f"[SKIP] {os.path.basename(f)} -> {e}")

    if not parts:
        raise RuntimeError("No valid csv files parsed. Check separator/format.")

    df = pd.concat(parts, ignore_index=True)
    df = df.sort_values("open_time")
    df = df.drop_duplicates(subset=["open_time"], keep="last").reset_index(drop=True)

    # удобная колонка времени
    df["datetime_utc"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)

    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    df.to_csv(out_csv, index=False)

    print(f"\nParsed files OK: {ok}/{len(files)}")
    print(f"Saved: {out_csv}")
    print(f"Total rows: {len(df)}")
    print("Head:\n", df.head(3))
    print("Tail:\n", df.tail(3))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inp", required=True, help="Folder with Binance kline CSV parts")
    ap.add_argument("--out", required=True, help="Output merged CSV")
    args = ap.parse_args()
    merge_folder(args.inp, args.out)

if __name__ == "__main__":
    main()
