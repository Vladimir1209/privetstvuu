import os, json, argparse
import numpy as np
import pandas as pd

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

BARS_PER_DAY_3M = 24 * 60 // 3  # 480


class TradeNet(nn.Module):
    def __init__(self, n_features: int, hidden=128, cnn_channels=128, dropout=0.1):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(n_features, cnn_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.gru = nn.GRU(
            input_size=cnn_channels,
            hidden_size=hidden,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
        )
        feat_dim = hidden * 2
        self.head_side = nn.Sequential(
            nn.Linear(feat_dim, feat_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(feat_dim // 2, 2),
        )

    def forward(self, x):
        x = x.transpose(1, 2)  # (B,F,T)
        x = self.cnn(x)        # (B,C,T)
        x = x.transpose(1, 2)  # (B,T,C)
        out, _ = self.gru(x)
        feat = out[:, -1, :]
        return self.head_side(feat)


def load_ohlcv(csv_path: str) -> pd.DataFrame:
    df0 = pd.read_csv(csv_path)
    if df0.shape[1] < 5:
        df0 = pd.read_csv(csv_path, header=None)

    cols = list(df0.columns)
    lower = [str(c).strip().lower() for c in cols]

    def find_any(names):
        for n in names:
            for i, c in enumerate(lower):
                if c == n:
                    return cols[i]
        return None

    o_col = find_any(["open","o"])
    h_col = find_any(["high","h"])
    l_col = find_any(["low","l"])
    c_col = find_any(["close","c"])
    if any(x is None for x in [o_col,h_col,l_col,c_col]):
        o_col,h_col,l_col,c_col = cols[1],cols[2],cols[3],cols[4]

    d = pd.DataFrame({
        "open": pd.to_numeric(df0[o_col], errors="coerce"),
        "high": pd.to_numeric(df0[h_col], errors="coerce"),
        "low":  pd.to_numeric(df0[l_col], errors="coerce"),
        "close":pd.to_numeric(df0[c_col], errors="coerce"),
    }).dropna().reset_index(drop=True)
    return d


def evaluate_trade_ohlc(df: pd.DataFrame, side: str, entry_i: int, sl: float, tp: float, horizon: int):
    h = df["high"].to_numpy(np.float64)
    l = df["low"].to_numpy(np.float64)
    end = min(len(df), entry_i + 1 + horizon)
    for i in range(entry_i + 1, end):
        if side == "LONG":
            hit_sl = l[i] <= sl
            hit_tp = h[i] >= tp
            if hit_sl and hit_tp: return "SL", i
            if hit_sl: return "SL", i
            if hit_tp: return "TP", i
        else:
            hit_sl = h[i] >= sl
            hit_tp = l[i] <= tp
            if hit_sl and hit_tp: return "SL", i
            if hit_sl: return "SL", i
            if hit_tp: return "TP", i
    return "TIMEOUT", end - 1


def max_drawdown_money(equity: np.ndarray) -> float:
    peak = -1e30
    mdd = 0.0
    for x in equity:
        peak = max(peak, x)
        mdd = max(mdd, peak - x)
    return float(mdd)


class WindowDataset(Dataset):
    def __init__(self, samples_dir: str, labels_df: pd.DataFrame, indices: np.ndarray, mean: np.ndarray, std: np.ndarray):
        self.samples_dir = samples_dir
        self.labels = labels_df
        self.indices = indices.astype(int)
        self.mean = mean
        self.std = std

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, k):
        i = int(self.indices[k])
        sid = str(self.labels.loc[i, "sample_id"]).zfill(7)
        X = np.load(os.path.join(self.samples_dir, f"{sid}.npz"))["X"].astype(np.float32)
        X = (X - self.mean[None, :]) / (self.std[None, :] + 1e-8)
        y = 1 if str(self.labels.loc[i, "side"]).upper() == "LONG" else 0
        return torch.from_numpy(X), torch.tensor(y, dtype=torch.long)


def compute_mean_std(samples_dir: str, labels: pd.DataFrame, indices: np.ndarray):
    n_total = 0
    mean = None
    M2 = None
    for i in indices.astype(int):
        sid = str(labels.loc[i, "sample_id"]).zfill(7)
        X = np.load(os.path.join(samples_dir, f"{sid}.npz"))["X"].astype(np.float64)
        if mean is None:
            mean = np.zeros(X.shape[1], dtype=np.float64)
            M2 = np.zeros(X.shape[1], dtype=np.float64)

        n = X.shape[0]
        bmean = X.mean(axis=0)
        bvar = X.var(axis=0)
        n_new = n_total + n
        delta = bmean - mean
        mean = mean + delta * (n / max(1, n_new))
        M2 = M2 + bvar * n + (delta ** 2) * (n_total * n / max(1, n_new))
        n_total = n_new

    var = M2 / max(1, n_total)
    std = np.sqrt(np.maximum(var, 1e-12))
    return mean.astype(np.float32), std.astype(np.float32)


def set_seed(seed: int):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def train_one_model(samples_dir, labels_df, train_idx, mean, std, seed, epochs=10, bs=64, lr=2e-4, torch_threads=1):
    torch.set_num_threads(int(torch_threads))
    set_seed(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_cuda = torch.cuda.is_available()

    sid0 = str(labels_df.loc[int(train_idx[0]), "sample_id"]).zfill(7)
    X0 = np.load(os.path.join(samples_dir, f"{sid0}.npz"))["X"]
    n_features = int(X0.shape[1])

    ds = WindowDataset(samples_dir, labels_df, train_idx, mean, std)
    loader = DataLoader(ds, batch_size=bs, shuffle=True, num_workers=0, pin_memory=False)

    model = TradeNet(n_features=n_features, hidden=128, cnn_channels=128, dropout=0.1).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    ce = nn.CrossEntropyLoss()
    scaler = torch.amp.GradScaler("cuda", enabled=use_cuda)

    for _ in range(epochs):
        model.train()
        for X, y in loader:
            X = X.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=use_cuda):
                logits = model(X)
                loss = ce(logits, y)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

    model.eval()
    return model


@torch.no_grad()
def ensemble_predict(models, Xt):
    # returns (side, conf_avg, votes_long, votes_short)
    probs = []
    for m in models:
        logits = m(Xt)
        p = torch.softmax(logits, dim=1)[0]
        probs.append(p.detach().cpu().numpy())
    probs = np.stack(probs, axis=0)  # (M,2)
    mean_p = probs.mean(axis=0)
    pred = int(np.argmax(mean_p))
    side = "LONG" if pred == 1 else "SHORT"
    conf = float(np.max(mean_p))
    votes = np.argmax(probs, axis=1)
    v_short = int((votes == 0).sum())
    v_long = int((votes == 1).sum())
    return side, conf, v_long, v_short


@torch.no_grad()
def backtest_risk_ensemble(models, mean, std, samples_dir, labels_df, test_idx, ohlcv_df,
                           conf=0.55, risk_pct=0.01, fee=0.0004, horizon=200,
                           no_overlap=True, start_capital=1000.0, min_votes=3):

    device = next(models[0].parameters()).device
    use_cuda = torch.cuda.is_available()

    cap = float(start_capital)
    busy_until = -1
    equity = []
    wins = losses = 0
    gp = gl = 0.0
    trades = 0

    for i in test_idx.astype(int):
        row = labels_df.loc[i]
        entry_i = int(row["entry_i"])
        if no_overlap and entry_i <= busy_until:
            continue

        sid = str(row["sample_id"]).zfill(7)
        npz_path = os.path.join(samples_dir, f"{sid}.npz")
        if not os.path.exists(npz_path):
            continue

        X = np.load(npz_path)["X"].astype(np.float32)
        Xn = (X - mean[None, :]) / (std[None, :] + 1e-8)
        Xt = torch.from_numpy(Xn).unsqueeze(0).to(device)

        with torch.amp.autocast("cuda", enabled=use_cuda):
            side, c, v_long, v_short = ensemble_predict(models, Xt)

        if max(v_long, v_short) < min_votes:
            continue
        if c < conf:
            continue

        entry = float(row["entry"]); sl = float(row["sl"]); tp = float(row["tp"])
        risk_dist = abs(entry - sl)
        if risk_dist <= 0 or entry <= 0 or cap <= 0:
            continue

        qty = (cap * risk_pct) / risk_dist

        outcome, exit_i = evaluate_trade_ohlc(ohlcv_df, side, entry_i, sl, tp, horizon)
        exit_price = {"TP": tp, "SL": sl, "TIMEOUT": float(ohlcv_df.loc[exit_i, "close"])}[outcome]

        pnl_money = (exit_price - entry) * qty if side == "LONG" else (entry - exit_price) * qty
        fees_money = fee * (abs(entry * qty) + abs(exit_price * qty))
        pnl_net = pnl_money - fees_money

        cap_new = cap + pnl_net
        trades += 1

        if pnl_net > 0:
            wins += 1; gp += pnl_net
        else:
            losses += 1; gl += -pnl_net

        cap = cap_new
        equity.append(cap)

        if no_overlap:
            busy_until = int(exit_i)
        if cap <= 0:
            break

    if trades == 0:
        return {"trades": 0, "profit_factor": None, "return_pct": 0.0, "max_drawdown_money": None}

    pf = (gp / gl) if gl > 1e-12 else float("inf")
    eq = np.array(equity, dtype=np.float64)
    return {
        "trades": int(trades),
        "winrate": float(wins / trades),
        "wins": int(wins),
        "losses": int(losses),
        "profit_factor": float(pf),
        "start_capital": float(start_capital),
        "end_capital": float(cap),
        "return_pct": float(cap / start_capital - 1.0),
        "max_drawdown_money": float(max_drawdown_money(eq)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--labels", required=True)
    ap.add_argument("--csv", required=True)
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", default="wf_ensemble")

    ap.add_argument("--train_months", type=int, default=6)
    ap.add_argument("--test_months", type=int, default=2)

    ap.add_argument("--conf", type=float, default=0.55)
    ap.add_argument("--risk_pct", type=float, default=0.01)
    ap.add_argument("--fee", type=float, default=0.0004)
    ap.add_argument("--horizon", type=int, default=200)
    ap.add_argument("--no_overlap", type=int, default=1)
    ap.add_argument("--start_capital", type=float, default=1000.0)

    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--torch_threads", type=int, default=1)

    ap.add_argument("--ensemble", type=int, default=5)
    ap.add_argument("--min_votes", type=int, default=3)

    ap.add_argument("--min_train_trades", type=int, default=200)
    ap.add_argument("--min_test_trades", type=int, default=60)

    ap.add_argument("--seed0", type=int, default=123)

    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    labels = pd.read_csv(args.labels)
    labels = labels.sort_values("entry_i").reset_index(drop=True)

    samples_dir = os.path.join(args.dataset, "samples")
    ohlcv = load_ohlcv(args.csv)

    train_bars = int(args.train_months * 30 * BARS_PER_DAY_3M)
    test_bars = int(args.test_months * 30 * BARS_PER_DAY_3M)
    step_bars = test_bars

    min_bar = int(labels["entry_i"].min())
    max_bar = int(labels["entry_i"].max())

    start_bar = min_bar
    wf_id = 0
    results = []

    while start_bar + train_bars + test_bars <= max_bar:
        train_lo = start_bar
        train_hi = start_bar + train_bars
        test_lo = train_hi
        test_hi = train_hi + test_bars

        train_slice = labels[(labels["entry_i"] >= train_lo) & (labels["entry_i"] < train_hi)]
        test_slice = labels[(labels["entry_i"] >= test_lo) & (labels["entry_i"] < test_hi)]

        if len(train_slice) < args.min_train_trades or len(test_slice) < args.min_test_trades:
            start_bar += step_bars
            continue

        wf_id += 1
        wf_dir = os.path.join(args.out, f"wf_{wf_id:02d}")
        os.makedirs(wf_dir, exist_ok=True)

        train_idx = train_slice.index.to_numpy()
        test_idx = test_slice.index.to_numpy()

        # shared stats per window
        mean, std = compute_mean_std(samples_dir, labels, train_idx)

        # train ensemble
        models = []
        for m in range(args.ensemble):
            seed = int(args.seed0 + 1000 * wf_id + m)
            models.append(train_one_model(
                samples_dir=samples_dir,
                labels_df=labels,
                train_idx=train_idx,
                mean=mean,
                std=std,
                seed=seed,
                epochs=args.epochs,
                bs=args.bs,
                lr=2e-4,
                torch_threads=args.torch_threads,
            ))

        res = backtest_risk_ensemble(
            models=models,
            mean=mean,
            std=std,
            samples_dir=samples_dir,
            labels_df=labels,
            test_idx=test_idx,
            ohlcv_df=ohlcv,
            conf=args.conf,
            risk_pct=args.risk_pct,
            fee=args.fee,
            horizon=args.horizon,
            no_overlap=bool(args.no_overlap),
            start_capital=args.start_capital,
            min_votes=args.min_votes,
        )

        res.update({
            "wf_id": wf_id,
            "ensemble": int(args.ensemble),
            "min_votes": int(args.min_votes),
            "train_trades": int(len(train_slice)),
            "test_trades": int(len(test_slice)),
        })
        results.append(res)

        with open(os.path.join(wf_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)

        print(f"WF[{wf_id:02d}] PF={res['profit_factor']:.3f} RET={res['return_pct']:.3f} "
              f"DD={res['max_drawdown_money']:.1f} trades={res['trades']}")

        start_bar += step_bars

    out_csv = os.path.join(args.out, "walk_forward_results.csv")
    dfres = pd.DataFrame(results)
    dfres.to_csv(out_csv, index=False)

    print("\nDONE WF ENSEMBLE")
    print("Saved:", out_csv)
    if len(dfres) == 0:
        print("No windows.")
        return
    print("Mean PF:", float(dfres["profit_factor"].mean()))
    print("Mean Return:", float(dfres["return_pct"].mean()))
    print("Worst Return:", float(dfres["return_pct"].min()))
    print("Best Return:", float(dfres["return_pct"].max()))


if __name__ == "__main__":
    main()


