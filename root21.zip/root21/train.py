import os
import json
import argparse
from typing import Tuple

import numpy as np
import pandas as pd

# ---- reduce CPU thread noise (safe defaults) ----
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


# =========================
# Split (time-based)
# =========================
def time_split_indices(n: int, val_frac=0.15, test_frac=0.15):
    n_test = int(n * test_frac)
    n_val = int(n * val_frac)
    train_end = n - (n_val + n_test)
    val_end = n - n_test
    return np.arange(0, train_end), np.arange(train_end, val_end), np.arange(val_end, n)


def load_labels(labels_csv: str) -> pd.DataFrame:
    df = pd.read_csv(labels_csv)
    # IMPORTANT: keep time order by entry_i if exists
    if "entry_i" in df.columns:
        df = df.sort_values("entry_i").reset_index(drop=True)
    return df


def side_to_int(side: str) -> int:
    return 1 if str(side).upper() == "LONG" else 0


# =========================
# Dataset
# =========================
class NPZTradesDataset(Dataset):
    def __init__(
        self,
        samples_dir: str,
        labels: pd.DataFrame,
        indices: np.ndarray,
        mean: np.ndarray = None,
        std: np.ndarray = None,
        use_outcome: bool = True
    ):
        self.samples_dir = samples_dir
        self.labels = labels
        self.indices = indices.astype(int)
        self.mean = mean
        self.std = std
        self.use_outcome = bool(use_outcome) and ("outcome" in labels.columns)

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, k):
        i = int(self.indices[k])
        sid = str(self.labels.loc[i, "sample_id"]).zfill(7)
        X = np.load(os.path.join(self.samples_dir, f"{sid}.npz"))["X"].astype(np.float32)  # (T,F)

        if self.mean is not None and self.std is not None:
            X = (X - self.mean[None, :]) / (self.std[None, :] + 1e-8)

        row = self.labels.loc[i]

        # ---- targets ----
        y_side = side_to_int(row["side"])  # 1=LONG, 0=SHORT

        # regress in % of entry (scale-invariant)
        entry = float(row["entry"])
        sl = float(row["sl"])
        tp = float(row["tp"])
        y_entry = 0.0
        y_sl = (sl - entry) / (entry + 1e-12)
        y_tp = (tp - entry) / (entry + 1e-12)
        y_reg = np.array([y_entry, y_sl, y_tp], dtype=np.float32)

        # outcome: 0 loss, 1 win, 2 timeout
        if self.use_outcome:
            outc = int(row["outcome"])
            y_out = 2 if outc == -1 else outc
        else:
            y_out = -1

        return (
            torch.from_numpy(X),
            torch.tensor(y_side, dtype=torch.long),
            torch.from_numpy(y_reg),
            torch.tensor(y_out, dtype=torch.long),
        )


def compute_mean_std(samples_dir: str, labels: pd.DataFrame, indices: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Streaming mean/std across all timesteps, over given indices.
    """
    n_total = 0
    mean = None
    M2 = None

    for i in indices.astype(int):
        sid = str(labels.loc[i, "sample_id"]).zfill(7)
        X = np.load(os.path.join(samples_dir, f"{sid}.npz"))["X"].astype(np.float64)  # (T,F)

        if mean is None:
            mean = np.zeros(X.shape[1], dtype=np.float64)
            M2 = np.zeros(X.shape[1], dtype=np.float64)

        n = X.shape[0]
        batch_mean = X.mean(axis=0)
        batch_var = X.var(axis=0)

        n_new = n_total + n
        delta = batch_mean - mean
        mean = mean + delta * (n / max(1, n_new))
        M2 = M2 + batch_var * n + (delta ** 2) * (n_total * n / max(1, n_new))
        n_total = n_new

    var = M2 / max(1, n_total)
    std = np.sqrt(np.maximum(var, 1e-12))
    return mean.astype(np.float32), std.astype(np.float32)


# =========================
# Model
# =========================
class TradeNet(nn.Module):
    """
    CNN1D over time + BiGRU + heads
    """
    def __init__(self, n_features: int, hidden=128, cnn_channels=128, dropout=0.1, use_outcome=True):
        super().__init__()
        self.use_outcome = use_outcome

        self.cnn = nn.Sequential(
            nn.Conv1d(n_features, cnn_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.gru = nn.GRU(
            input_size=cnn_channels,
            hidden_size=hidden,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        feat_dim = hidden * 2

        self.head_side = nn.Sequential(
            nn.Linear(feat_dim, feat_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(feat_dim // 2, 2),
        )

        self.head_reg = nn.Sequential(
            nn.Linear(feat_dim, feat_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(feat_dim // 2, 3),
        )

        if self.use_outcome:
            self.head_out = nn.Sequential(
                nn.Linear(feat_dim, feat_dim // 2),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(feat_dim // 2, 3),
            )

    def forward(self, x):
        # x: (B,T,F)
        x = x.transpose(1, 2)  # (B,F,T)
        x = self.cnn(x)        # (B,C,T)
        x = x.transpose(1, 2)  # (B,T,C)
        out, _ = self.gru(x)   # (B,T,2H)
        feat = out[:, -1, :]

        side_logits = self.head_side(feat)
        reg = self.head_reg(feat)
        out_logits = self.head_out(feat) if self.use_outcome else None
        return side_logits, reg, out_logits


# =========================
# Eval
# =========================
@torch.no_grad()
def evaluate(model, loader, device, use_outcome: bool):
    model.eval()
    ce = nn.CrossEntropyLoss()
    huber = nn.SmoothL1Loss()

    total = 0
    loss_sum = 0.0
    side_correct = 0

    out_correct = 0
    out_total = 0

    for X, y_side, y_reg, y_out in loader:
        X = X.to(device, non_blocking=True)
        y_side = y_side.to(device, non_blocking=True)
        y_reg = y_reg.to(device, non_blocking=True)

        side_logits, reg, out_logits = model(X)

        loss = ce(side_logits, y_side) + huber(reg, y_reg)

        pred_side = side_logits.argmax(dim=1)
        side_correct += int((pred_side == y_side).sum().item())

        if use_outcome and out_logits is not None and (y_out.min().item() >= 0):
            y_out = y_out.to(device, non_blocking=True)
            loss = loss + ce(out_logits, y_out)
            out_pred = out_logits.argmax(dim=1)
            out_correct += int((out_pred == y_out).sum().item())
            out_total += int(y_out.numel())

        b = X.shape[0]
        total += b
        loss_sum += float(loss.item()) * b

    return {
        "loss": loss_sum / max(1, total),
        "side_acc": side_correct / max(1, total),
        "out_acc": (out_correct / max(1, out_total)) if out_total > 0 else None,
    }


def make_loader(ds, bs: int, shuffle: bool, num_workers: int, pin_memory: bool, use_cuda: bool):
    return DataLoader(
        ds,
        batch_size=bs,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=bool(pin_memory) and use_cuda,
        persistent_workers=False,
        prefetch_factor=2 if num_workers > 0 else None,
        drop_last=False,
    )


# =========================
# Train (with split)
# =========================
def train(args):
    if args.torch_threads is not None:
        torch.set_num_threads(int(args.torch_threads))
    if args.interop_threads is not None:
        torch.set_num_interop_threads(int(args.interop_threads))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_cuda = torch.cuda.is_available()

    labels = load_labels(args.labels)
    samples_dir = os.path.join(args.data, "samples")

    n = len(labels)
    tr_idx, va_idx, te_idx = time_split_indices(n, val_frac=args.val_frac, test_frac=args.test_frac)

    print(f"Total samples: {n} | train={len(tr_idx)} val={len(va_idx)} test={len(te_idx)}")

    mean, std = compute_mean_std(samples_dir, labels, tr_idx)

    os.makedirs(args.out, exist_ok=True)
    np.savez_compressed(os.path.join(args.out, "stats.npz"), mean=mean, std=std)

    with open(os.path.join(args.out, "split.json"), "w", encoding="utf-8") as f:
        json.dump({
            "n": n,
            "train": [int(tr_idx[0]), int(tr_idx[-1])],
            "val": [int(va_idx[0]), int(va_idx[-1])],
            "test": [int(te_idx[0]), int(te_idx[-1])],
        }, f, ensure_ascii=False, indent=2)

    sid0 = str(labels.loc[int(tr_idx[0]), "sample_id"]).zfill(7)
    X0 = np.load(os.path.join(samples_dir, f"{sid0}.npz"))["X"]
    n_features = int(X0.shape[1])

    use_outcome = bool(args.use_outcome) and ("outcome" in labels.columns)

    ds_tr = NPZTradesDataset(samples_dir, labels, tr_idx, mean, std, use_outcome=use_outcome)
    ds_va = NPZTradesDataset(samples_dir, labels, va_idx, mean, std, use_outcome=use_outcome)
    ds_te = NPZTradesDataset(samples_dir, labels, te_idx, mean, std, use_outcome=use_outcome)

    tr_loader = make_loader(ds_tr, args.bs, True, args.num_workers, args.pin_memory, use_cuda)
    va_loader = make_loader(ds_va, args.bs, False, args.num_workers, args.pin_memory, use_cuda)
    te_loader = make_loader(ds_te, args.bs, False, args.num_workers, args.pin_memory, use_cuda)

    model = TradeNet(
        n_features=n_features,
        hidden=args.hidden,
        cnn_channels=args.cnn_channels,
        dropout=args.dropout,
        use_outcome=use_outcome
    ).to(device)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.wd)
    ce = nn.CrossEntropyLoss()
    huber = nn.SmoothL1Loss()
    scaler = torch.amp.GradScaler("cuda", enabled=use_cuda)

    best_val = 1e18
    best_path = os.path.join(args.out, "model_best.pt")

    with open(os.path.join(args.out, "config.json"), "w", encoding="utf-8") as f:
        json.dump(vars(args), f, ensure_ascii=False, indent=2)

    for epoch in range(1, args.epochs + 1):
        model.train()
        total = 0
        loss_sum = 0.0

        for X, y_side, y_reg, y_out in tr_loader:
            X = X.to(device, non_blocking=True)
            y_side = y_side.to(device, non_blocking=True)
            y_reg = y_reg.to(device, non_blocking=True)

            opt.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=use_cuda):
                side_logits, reg, out_logits = model(X)

                loss_side = ce(side_logits, y_side)
                loss_reg = huber(reg, y_reg) * args.lambda_reg
                loss = loss_side + loss_reg

                if use_outcome and out_logits is not None and (y_out.min().item() >= 0):
                    y_out = y_out.to(device, non_blocking=True)
                    loss_out = ce(out_logits, y_out) * args.lambda_outcome
                    loss = loss + loss_out

            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

            b = X.shape[0]
            total += b
            loss_sum += float(loss.item()) * b

        train_loss = loss_sum / max(1, total)
        val_metrics = evaluate(model, va_loader, device, use_outcome=use_outcome)

        print(
            f"[{epoch:02d}/{args.epochs}] "
            f"train_loss={train_loss:.6f} | "
            f"val_loss={val_metrics['loss']:.6f} | "
            f"val_side_acc={val_metrics['side_acc']:.4f}"
        )

        if val_metrics["loss"] < best_val:
            best_val = val_metrics["loss"]
            torch.save({
                "model": model.state_dict(),
                "n_features": n_features,
                "hidden": args.hidden,
                "cnn_channels": args.cnn_channels,
                "dropout": args.dropout,
                "use_outcome": use_outcome,
            }, best_path)

    # test best
    ckpt = torch.load(best_path, map_location=device)
    model.load_state_dict(ckpt["model"])
    test_metrics = evaluate(model, te_loader, device, use_outcome=use_outcome)
    print("BEST VAL:", best_val)
    print("TEST:", test_metrics)
    print("Saved:", best_path)
    print("Saved stats:", os.path.join(args.out, "stats.npz"))


# =========================
# Train FULL (100% samples)
# =========================
def train_full(args):
    """
    Train on ALL samples (no split). Use mean/std computed on ALL samples.
    Saves: out/model_full.pt and out/stats_full.npz
    """
    if args.torch_threads is not None:
        torch.set_num_threads(int(args.torch_threads))
    if args.interop_threads is not None:
        torch.set_num_interop_threads(int(args.interop_threads))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_cuda = torch.cuda.is_available()

    labels = load_labels(args.labels)
    samples_dir = os.path.join(args.data, "samples")
    n = len(labels)
    all_idx = np.arange(n)

    print(f"Total samples (FULL): {n}")

    mean, std = compute_mean_std(samples_dir, labels, all_idx)

    os.makedirs(args.out, exist_ok=True)
    np.savez_compressed(os.path.join(args.out, "stats_full.npz"), mean=mean, std=std)

    sid0 = str(labels.loc[0, "sample_id"]).zfill(7)
    X0 = np.load(os.path.join(samples_dir, f"{sid0}.npz"))["X"]
    n_features = int(X0.shape[1])

    use_outcome = bool(args.use_outcome) and ("outcome" in labels.columns)

    ds = NPZTradesDataset(samples_dir, labels, all_idx, mean, std, use_outcome=use_outcome)
    loader = make_loader(ds, args.bs, True, args.num_workers, args.pin_memory, use_cuda)

    model = TradeNet(
        n_features=n_features,
        hidden=args.hidden,
        cnn_channels=args.cnn_channels,
        dropout=args.dropout,
        use_outcome=use_outcome
    ).to(device)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.wd)
    ce = nn.CrossEntropyLoss()
    huber = nn.SmoothL1Loss()
    scaler = torch.amp.GradScaler("cuda", enabled=use_cuda)

    out_path = os.path.join(args.out, "model_full.pt")

    with open(os.path.join(args.out, "config_full.json"), "w", encoding="utf-8") as f:
        json.dump(vars(args), f, ensure_ascii=False, indent=2)

    for epoch in range(1, args.epochs + 1):
        model.train()
        total = 0
        loss_sum = 0.0
        side_correct = 0

        for X, y_side, y_reg, y_out in loader:
            X = X.to(device, non_blocking=True)
            y_side = y_side.to(device, non_blocking=True)
            y_reg = y_reg.to(device, non_blocking=True)

            opt.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=use_cuda):
                side_logits, reg, out_logits = model(X)

                loss_side = ce(side_logits, y_side)
                loss_reg = huber(reg, y_reg) * args.lambda_reg
                loss = loss_side + loss_reg

                if use_outcome and out_logits is not None and (y_out.min().item() >= 0):
                    y_out = y_out.to(device, non_blocking=True)
                    loss_out = ce(out_logits, y_out) * args.lambda_outcome
                    loss = loss + loss_out

            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

            pred_side = side_logits.argmax(dim=1)
            side_correct += int((pred_side == y_side).sum().item())

            b = X.shape[0]
            total += b
            loss_sum += float(loss.item()) * b

        train_loss = loss_sum / max(1, total)
        train_acc = side_correct / max(1, total)
        print(
            f"[{epoch:02d}/{args.epochs}] "
            f"FULL train_loss={train_loss:.6f} | train_side_acc={train_acc:.4f} | samples={n}"
        )

    torch.save({
        "model": model.state_dict(),
        "n_features": n_features,
        "hidden": args.hidden,
        "cnn_channels": args.cnn_channels,
        "dropout": args.dropout,
        "use_outcome": use_outcome,
    }, out_path)

    print("SAVED FULL MODEL:", out_path)
    print("SAVED FULL STATS:", os.path.join(args.out, "stats_full.npz"))


# =========================
# Predict
# =========================
@torch.no_grad()
def predict(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_cuda = torch.cuda.is_available()

    ckpt = torch.load(args.model, map_location=device)
    st = np.load(args.stats)
    mean = st["mean"].astype(np.float32)
    std = st["std"].astype(np.float32)

    X = np.load(args.sample)["X"].astype(np.float32)
    Xn = (X - mean[None, :]) / (std[None, :] + 1e-8)
    Xt = torch.from_numpy(Xn).unsqueeze(0).to(device)

    model = TradeNet(
        n_features=int(ckpt["n_features"]),
        hidden=int(ckpt.get("hidden", 128)),
        cnn_channels=int(ckpt.get("cnn_channels", 128)),
        dropout=float(ckpt.get("dropout", 0.1)),
        use_outcome=bool(ckpt.get("use_outcome", False)),
    ).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    with torch.amp.autocast("cuda", enabled=use_cuda):
        side_logits, reg, out_logits = model(Xt)

    p = torch.softmax(side_logits, dim=1)[0].cpu().numpy()
    side = "LONG" if int(np.argmax(p)) == 1 else "SHORT"

    reg = reg[0].cpu().numpy()
    out = {
        "side": side,
        "p_short": float(p[0]),
        "p_long": float(p[1]),
        "sl_pct_from_entry": float(reg[1]),
        "tp_pct_from_entry": float(reg[2]),
    }
    if out_logits is not None:
        po = torch.softmax(out_logits, dim=1)[0].cpu().numpy()
        out["p_loss"] = float(po[0])
        out["p_win"] = float(po[1])
        out["p_timeout"] = float(po[2])

    print(json.dumps(out, ensure_ascii=False, indent=2))


# =========================
# CLI
# =========================
def add_common_train_args(p):
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--bs", type=int, default=64)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--wd", type=float, default=1e-4)

    # CPU load knobs
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--pin_memory", type=int, default=0)
    p.add_argument("--torch_threads", type=int, default=1)
    p.add_argument("--interop_threads", type=int, default=1)

    p.add_argument("--hidden", type=int, default=128)
    p.add_argument("--cnn_channels", type=int, default=128)
    p.add_argument("--dropout", type=float, default=0.1)

    p.add_argument("--use_outcome", type=int, default=1)
    p.add_argument("--lambda_outcome", type=float, default=0.4)
    p.add_argument("--lambda_reg", type=float, default=1.0)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    # train with split
    tr = sub.add_parser("train")
    tr.add_argument("--data", required=True, help="dataset folder (contains samples/)")
    tr.add_argument("--labels", required=True, help="labels.csv path")
    tr.add_argument("--out", required=True, help="output folder")
    tr.add_argument("--val_frac", type=float, default=0.15)
    tr.add_argument("--test_frac", type=float, default=0.15)
    add_common_train_args(tr)

    # train on full dataset
    trf = sub.add_parser("train_full")
    trf.add_argument("--data", required=True)
    trf.add_argument("--labels", required=True)
    trf.add_argument("--out", required=True)
    add_common_train_args(trf)

    # predict
    pr = sub.add_parser("predict")
    pr.add_argument("--model", required=True)
    pr.add_argument("--stats", required=True)
    pr.add_argument("--sample", required=True)

    args = ap.parse_args()

    if args.cmd == "train":
        train(args)
    elif args.cmd == "train_full":
        train_full(args)
    else:
        predict(args)


if __name__ == "__main__":
    main()
